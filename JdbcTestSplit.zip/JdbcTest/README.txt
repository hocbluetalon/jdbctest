Usage: -u <jdbcUrl> [-n <user>] [-p <password>] [-K] -c <jdbcDriverClass> [-d <Database>] [-s <Schema>] [ -q <query>|-x <stmt>]
 For Kerberos auth, pass -K option. Also make sure you have a valid ticket prior to executing this tool.

Bundled JDBC driver classes
Hive: org.apache.hive.jdbc.HiveDriver
Postgress/Greenplum: org.postgresql.Driver
